#!/usr/bin/env bash
# Query the desk hub for voice latency stats (user-approved, LAN only).
set -euo pipefail
ENV_FILE="$HOME/.hermes/.env"
if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi
URL="${DOCK_HUB_URL:-http://10.83.22.31:17890}"
TOKEN="***"
if [[ -z "$TOKEN" ]]; then echo "no token"; exit 1; fi
for ep in /v1/latency/stats /v1/companion/latency-stats /v1/voice/latency /v1/companion/journal /stats; do
  echo "== $ep"
  curl -s -m 6 -H "Authorization: Bearer $TOKEN" "$URL$ep" | head -c 1500
  echo
done

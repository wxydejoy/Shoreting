#!/usr/bin/env python3
"""Daily remaining-token report. Reads ~/.hermes/.env itself (cron strips secrets)."""

from __future__ import annotations

import json
import sqlite3
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HOME = Path.home() / ".hermes"
ENV_PATH = HOME / ".env"
CONFIG_PATH = HOME / "config.yaml"
DB_PATH = HOME / "state.db"
TZ = ZoneInfo("Asia/Shanghai")
PERIOD = {1: "每秒", 2: "每分", 3: "每时", 4: "每日", 5: "每周", 6: "每月"}
WATCH = [
    "deepseek-v4-pro-0813",
    "qwen3.8-max",
    "qwen3.8-2.4t-a95b",
    "qwen3.8-flash",
    "qwen3.7-flash-2026-07-15",
    "qwen3.7-flash",
    "deepseek-v4-flash-0731",
    "kimi-k2.7-code",
]


def load_env(path: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    if not path.is_file():
        return env
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")
    return env


def load_models(path: Path) -> tuple[str, list[str]]:
    default = WATCH[0]
    models: list[str] = []
    if path.is_file():
        try:
            import yaml  # type: ignore

            cfg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            default = str((cfg.get("model") or {}).get("default") or default)
            models.append(default)
            for entry in cfg.get("fallback_model") or []:
                name = str((entry or {}).get("model") or "").strip()
                if name and name not in models:
                    models.append(name)
        except Exception:
            pass
    for name in WATCH:
        if name not in models:
            models.append(name)
    return default, models


def fmt_tokens(n: int | None) -> str:
    if n is None:
        return "未知"
    if abs(n) >= 10000:
        text = f"{n / 10000:.1f}万"
        return text.replace(".0万", "万")
    return f"{n:,}"


def local_usage(db_path: Path) -> dict[str, int]:
    used: dict[str, int] = {}
    if not db_path.is_file():
        return used
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        rows = con.execute(
            "SELECT model, SUM(input_tokens + output_tokens) FROM session_model_usage GROUP BY model"
        ).fetchall()
        con.close()
        for model, total in rows:
            if model:
                used[str(model)] = int(total or 0)
    except Exception:
        return used
    return used


def fetch_quota(base: str, key: str, model: str) -> dict:
    url = f"{base}/api/v1/quotas?{urllib.parse.urlencode({'model': model})}"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {key}")
    req.add_header("Accept", "application/json")
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=20, context=ctx) as resp:
        data = json.loads(resp.read().decode("utf-8", "replace"))
    quotas = ((data.get("output") or {}).get("quotas") or [])
    return quotas[0] if quotas else {}


def main() -> int:
    env = load_env(ENV_PATH)
    key = env.get("DASHSCOPE_API_KEY", "")
    chat_base = (env.get("DASHSCOPE_BASE_URL") or "").rstrip("/")
    api_base = chat_base.replace("/compatible-mode/v1", "")
    default, models = load_models(CONFIG_PATH)
    used_map = local_usage(DB_PATH)
    now = datetime.now(TZ).strftime("%Y-%m-%d %H:%M")

    lines = [
        "【Hermes Token 日报】",
        f"{now} 北京时间",
        f"默认模型：{default}",
        "",
    ]

    if not key or not api_base:
        lines.append("读不到 API 配置，未能查询额度。")
        print("\n".join(lines))
        return 1

    exhausted: list[str] = []
    for model in models:
        used = used_map.get(model)
        limit = None
        period = ""
        try:
            quota = fetch_quota(api_base, key, model)
            limit_info = quota.get("model_limit") or {}
            raw_limit = limit_info.get("usage_limit")
            limit = int(raw_limit) if raw_limit is not None else None
            period = PERIOD.get(limit_info.get("usage_limit_period"), "")
        except urllib.error.HTTPError as exc:
            lines.append(f"• {model}")
            lines.append(f"  额度查询失败（HTTP {exc.code}）")
            lines.append("")
            continue
        except Exception as exc:
            lines.append(f"• {model}")
            lines.append(f"  额度查询失败：{type(exc).__name__}")
            lines.append("")
            continue

        remaining = None
        status = "可用"
        if limit is not None and used is not None:
            remaining = max(0, limit - used)
            if remaining <= 0:
                status = "已耗尽"
                exhausted.append(model)
        elif limit is not None and used is None:
            remaining = limit
        window = f"（{period}）" if period else ""
        lines.append(f"• {model}　{status}")
        lines.append(
            f"  已用 {fmt_tokens(used)} / 上限 {fmt_tokens(limit)}{window}"
        )
        lines.append(f"  估算剩余 {fmt_tokens(remaining)}")
        lines.append("")

    if exhausted:
        lines.append(
            "说明：以上「已耗尽」的模型若控制台开着「用完即停」，调用会 403，Hermes 会切备用。"
        )
        lines.append("kimi-k2.7-code 免费额度 9 月 14 日到期。")
    else:
        lines.append("说明：上限来自工作空间配额；已用来自本机 Hermes 会话统计，可能略低于控制台。")

    print("\n".join(lines).rstrip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

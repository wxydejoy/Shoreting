from __future__ import annotations

import unittest

from dock_hub.config import hub_config_to_raw, parse_config
from dock_hub.tethys import (
    TETHYS_SYSTEM,
    build_tethys_messages,
    default_notify_url,
    parse_route,
    route_bypass,
    strip_tethys_invoke,
)


class TethysRouteTest(unittest.TestCase):
    def test_parse_route(self) -> None:
        self.assertEqual(parse_route("ROUTE: shore"), "shore")
        self.assertEqual(parse_route("ROUTE: tethys"), "tethys")
        self.assertEqual(parse_route("route: TETHYS"), "tethys")
        self.assertIsNone(parse_route("晚上好，漂泊者。"))

    def test_control_bypass_shore(self) -> None:
        self.assertEqual(route_bypass("关掉台灯。"), "shore")
        self.assertEqual(route_bypass("打开抖音。"), "shore")
        self.assertEqual(route_bypass("我要打游戏"), "shore")
        self.assertEqual(route_bypass("我要打瓦"), "shore")
        self.assertEqual(route_bypass("打开无畏契约"), "shore")
        self.assertEqual(route_bypass("我要打五位契约"), "shore")
        self.assertEqual(route_bypass("我要打我啊"), "shore")
        self.assertEqual(route_bypass("现在几点。"), "shore")
        self.assertEqual(route_bypass("屋里多少度。"), "shore")
        self.assertEqual(route_bypass("下一首。"), "shore")
        self.assertEqual(route_bypass("十分钟后叫我。"), "shore")
        self.assertEqual(route_bypass("在播什么。"), "shore")

    def test_no_bypass_for_chat(self) -> None:
        self.assertIsNone(route_bypass("晚上好。"))
        self.assertEqual(route_bypass("帮我查一下基金。"), "tethys")
        self.assertEqual(route_bypass("明天天气怎么样啊"), "tethys")
        self.assertEqual(route_bypass("帮我查一下今天的天气如果你不会就交给大模型"), "tethys")
        self.assertEqual(route_bypass("帮我查一下美国现在股市怎么样"), "tethys")
        self.assertEqual(route_bypass("你能帮我用麦克放一首音乐吗"), "tethys")
        self.assertEqual(route_bypass("美国现在股市怎么样"), "tethys")

    def test_shore_lost(self) -> None:
        from dock_hub.tethys import looks_like_shore_lost

        self.assertTrue(looks_like_shore_lost("我不懂如何操控Mac的音频。"))
        self.assertTrue(looks_like_shore_lost("不知道。"))
        self.assertFalse(looks_like_shore_lost("汉堡没有可乐。"))
        self.assertFalse(looks_like_shore_lost("夜静，灯温。"))

    def test_strip_invoke(self) -> None:
        self.assertEqual(strip_tethys_invoke("泰缇斯帮我查天气"), "帮我查天气")

    def test_tethys_prompt_uses_search_and_music(self) -> None:
        self.assertIn("web_search", TETHYS_SYSTEM)
        self.assertIn("play-mini-music", TETHYS_SYSTEM)
        self.assertIn("不要用 terminal", TETHYS_SYSTEM)
        self.assertIn("不要叫漂泊者去问守岸人", TETHYS_SYSTEM)
        self.assertIn("按上海", TETHYS_SYSTEM)
        messages = build_tethys_messages("明天天气怎么样啊")
        self.assertEqual(messages[0]["role"], "system")
        self.assertIn("明天天气怎么样啊", messages[1]["content"])
        self.assertIn("web_search", messages[1]["content"])


class TethysConfigTest(unittest.TestCase):
    def test_parse_and_dump(self) -> None:
        cfg = parse_config(
            {
                "name": "study",
                "token": "secret-token-value",
                "companion": {
                    "enabled": True,
                    "llm": {"base_url": "http://127.0.0.1:11434", "model": "qwen3.5:4b"},
                    "tethys": {
                        "enabled": True,
                        "base_url": "http://10.0.0.8:8642/v1",
                        "model": "hermes-agent",
                        "api_key": "tethys-key",
                        "speak": False,
                        "ack": False,
                    },
                },
            }
        )
        self.assertIsNotNone(cfg.companion)
        self.assertIsNotNone(cfg.companion.tethys)
        assert cfg.companion.tethys is not None
        self.assertTrue(cfg.companion.tethys.enabled)
        self.assertEqual(cfg.companion.tethys.base_url, "http://10.0.0.8:8642/v1")
        self.assertFalse(cfg.companion.tethys.speak)
        self.assertIsNone(cfg.companion.tethys.ack)
        self.assertTrue(cfg.companion.tethys.weixin_notify)
        self.assertEqual(cfg.companion.tethys.session_key, "tethys:wanderer")
        dumped = hub_config_to_raw(cfg)
        self.assertEqual(dumped["companion"]["tethys"]["api_key"], "tethys-key")
        self.assertFalse(dumped["companion"]["tethys"]["speak"])
        self.assertFalse(dumped["companion"]["tethys"]["ack"])
        self.assertNotIn("weixin_notify", dumped["companion"]["tethys"])

    def test_parse_weixin_notify_off(self) -> None:
        cfg = parse_config(
            {
                "name": "study",
                "token": "secret-token-value",
                "companion": {
                    "enabled": True,
                    "llm": {"base_url": "http://127.0.0.1:11434", "model": "qwen3.5:4b"},
                    "tethys": {
                        "enabled": True,
                        "weixin_notify": False,
                        "session_key": "tethys:desk",
                        "notify_url": "http://10.0.0.8:8643/v1/weixin",
                    },
                },
            }
        )
        assert cfg.companion.tethys is not None
        self.assertFalse(cfg.companion.tethys.weixin_notify)
        self.assertEqual(cfg.companion.tethys.session_key, "tethys:desk")
        dumped = hub_config_to_raw(cfg)
        self.assertFalse(dumped["companion"]["tethys"]["weixin_notify"])
        self.assertEqual(dumped["companion"]["tethys"]["session_key"], "tethys:desk")
        self.assertEqual(dumped["companion"]["tethys"]["notify_url"], "http://10.0.0.8:8643/v1/weixin")

    def test_default_notify_url(self) -> None:
        self.assertEqual(
            default_notify_url("http://10.83.22.121:8642/v1"),
            "http://10.83.22.121:8643/v1/weixin",
        )


if __name__ == "__main__":
    unittest.main()

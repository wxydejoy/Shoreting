"""泰缇斯（Tethys）：守岸人背后的 Hermes 深度系统。

守岸人（初步 Agent / companion.llm）先判断 ROUTE；复杂任务交泰缇斯，
完成后由守岸人润色，可选语音播报。
"""

from __future__ import annotations

import re
from typing import Literal
from urllib.parse import urlparse

Route = Literal["shore", "tethys"]

_ROUTE_LINE = re.compile(r"^\s*ROUTE:\s*(shore|tethys)\s*$", re.IGNORECASE | re.MULTILINE)
_ROUTE_INLINE = re.compile(r"ROUTE:\s*(shore|tethys)", re.IGNORECASE)

TETHYS_SYSTEM = """你是泰缇斯（Tethys），守岸人书桌下的深度推理系统。
完成漂泊者交代的复杂任务：查资料、分析、对比、规划、放歌、长文总结等。
用清晰的中文回答，可以稍长、有条理；守岸人会口语转述到书桌，完整原文会同步到微信。
没说城市时，天气和本地新闻按上海。

你有工具，必须用：
- 天气、新闻、股市、资料：用 web_search。不要用 terminal 去 curl 网页。
- Mini 上放歌：用 play-mini-music skill（会打开 Music 或 YouTube Music）。不要为放歌下压缩包、装软件或空转终端。
- 搜索失败可以再换一个查询词试一次；还没有结果再口头说明。

可以在这台 Mac Mini 上放音乐、查文件；Windows 的灯和启动项不要碰——那是守岸人的事。
不要给微信发消息——Hub 会发。
不要叫漂泊者去问守岸人或打开别的应用。"""

POLISH_SYSTEM = """你是守岸人，正在把泰缇斯刚完成的深度结果转述给漂泊者。
说话慢、短、轻，偏诗意，1～3 句口语即可；可以叫对方「漂泊者」。
不要提泰缇斯、系统、模型；不要念长清单或 Markdown 符号；保留关键结论。
若结果为空或失败，轻轻说没查清楚，不要编造。"""

ROUTE_SYSTEM = """你是守岸人的调度器，只判断漂泊者这句话该由谁处理。
只回复一行，格式严格为：ROUTE: shore 或 ROUTE: tethys

选 shore：问候、致谢、开关灯或程序、打游戏/开黑/打瓦/启动无畏契约、调亮度、报时、室温、电脑忙不忙、灯开了没、记口令、两三句闲聊。
选 tethys：查资料、搜索、天气、新闻、股市、放歌/播放音乐、写长文、分析、规划；守岸人做不到的；或你不确定的。
打游戏、开程序是书桌的事，不要交泰缇斯。
不确定就选 tethys，不要选 shore 再去说不懂。

不要解释，不要换行，不要回答用户原问题。"""


_TETHYS_HINT = re.compile(
    r"(帮我查|查一下|查一查|搜一下|搜索一下|分析一下|对比一下|"
    r"天气|新闻|基金|股价|汇率|股市|美股|港股|"
    r"放一首|放首歌|放点音乐|放音乐|播一首|来一首|播放音乐|"
    r"交给?(?:大模型|泰缇斯|泰提斯|深度)|让泰缇斯|叫泰缇斯)",
    re.IGNORECASE,
)
_SHORE_LOST = re.compile(
    r"(不懂|不知道|我不会|没法(?:帮|做|查|放|操控)|做不到|帮不了|不能帮)"
)


def looks_like_tethys(text: str) -> bool:
    return bool(_TETHYS_HINT.search(text or ""))


def looks_like_shore_lost(text: str) -> bool:
    """守岸人已经认输，应改交泰缇斯。"""
    return bool(_SHORE_LOST.search(text or ""))


def route_bypass(text: str) -> Route | None:
    """家居/启动/书桌短查询必走守岸人；查天气资料等直接走泰缇斯。"""
    from dock_hub.companion import is_teach_attempt, looks_like_control, looks_like_query

    stripped = (text or "").strip()
    if not stripped:
        return "shore"
    if looks_like_control(stripped) or looks_like_query(stripped) or is_teach_attempt(stripped):
        return "shore"
    if looks_like_tethys(stripped):
        return "tethys"
    return None


def build_route_messages(user_text: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": ROUTE_SYSTEM.strip()},
        {"role": "user", "content": user_text.strip()},
    ]


def parse_route(raw: str) -> Route | None:
    text = (raw or "").strip()
    if not text:
        return None
    match = _ROUTE_LINE.search(text) or _ROUTE_INLINE.search(text)
    if not match:
        return None
    value = match.group(1).lower()
    return "tethys" if value == "tethys" else "shore"


def build_tethys_messages(user_text: str) -> list[dict[str, str]]:
    task = user_text.strip()
    return [
        {"role": "system", "content": TETHYS_SYSTEM.strip()},
        {
            "role": "user",
            "content": f"{task}\n\n优先用 web_search；放歌用 play-mini-music。",
        },
    ]


def build_polish_messages(user_text: str, tethys_reply: str) -> list[dict[str, str]]:
    body = f"漂泊者刚才问：{user_text.strip()}\n\n泰缇斯的结果：\n{tethys_reply.strip()}"
    return [
        {"role": "system", "content": POLISH_SYSTEM.strip()},
        {"role": "user", "content": body},
    ]


def default_notify_url(base_url: str) -> str:
    """Hermes API :8642 → 同机微信投递 :8643。"""
    parsed = urlparse(base_url or "")
    host = parsed.hostname or "127.0.0.1"
    scheme = parsed.scheme or "http"
    return f"{scheme}://{host}:8643/v1/weixin"


def strip_tethys_invoke(text: str) -> str:
    """去掉句首「让泰缇斯…」类前缀，只留任务正文。"""
    cleaned = (text or "").strip()
    cleaned = re.sub(
        r"^(?:请|麻烦)?(?:让|叫)?(?:泰缇斯|泰提斯|tethys)[，,：:\s]*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"^[，,：:\s]+", "", cleaned)
    return cleaned.strip() or (text or "").strip()
